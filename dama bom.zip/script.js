const board = document.getElementById("board");
let selectedPiece = null;
let playerTurn = true;
let highlights = [];
let boardState = [];

initBoard();

function initBoard() {
  boardState = Array(8).fill(null).map(()=>Array(8).fill(null));
  board.innerHTML = "";
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const cell = document.createElement("div");
      cell.classList.add("cell", (r+c)%2===0 ? "white" : "black");
      cell.dataset.row = r;
      cell.dataset.col = c;
      board.appendChild(cell);

      if ((r+c)%2!==0) {
        if (r<3) addPiece(cell,"bot");
        else if (r>4) addPiece(cell,"player");
      }

      cell.addEventListener("click", ()=>onCellClick(r,c));
    }
  }
}

function addPiece(cell,type,king=false){
  const piece = {type, king};
  const div = document.createElement("div");
  div.classList.add("piece", type);
  if(king){
    div.classList.add("king");
    if(type==="player") div.style.backgroundColor="gold";
    if(type==="bot") div.style.backgroundColor="silver";
  }
  cell.appendChild(div);
  const r = parseInt(cell.dataset.row);
  const c = parseInt(cell.dataset.col);
  boardState[r][c] = piece;
}

function clearHighlights(){ highlights.forEach(h=>h.remove()); highlights=[]; }
function isInside(r,c){ return r>=0 && r<8 && c>=0 && c<8; }

function getMoves(sr, sc){
  const piece = boardState[sr][sc];
  if(!piece) return {simple:[], captures:[]};
  const simple=[], captures=[];
  const dirs=[[1,1],[1,-1],[-1,1],[-1,-1]];

  dirs.forEach(([dr,dc])=>{
    let r=sr+dr, c=sc+dc, captured=false, mid=null;
    while(isInside(r,c)){
      const target = boardState[r][c];
      if(!target){
        if(!captured) simple.push({r,c});
        else captures.push({r,c,mid});
        if(!piece.king) break;
        r+=dr; c+=dc;
      } else if(target.type!==piece.type && !captured){
        captured=true; mid={r,c}; r+=dr; c+=dc;
      } else break;
    }
  });

  return {simple,captures};
}

function showHighlights(sr, sc){
  clearHighlights();
  const {simple,captures} = getMoves(sr, sc);
  const paths = [...simple, ...captures];
  paths.forEach(p=>{
    const highlight = document.createElement("div");
    highlight.classList.add("highlight");
    const cell = board.children[p.r*8+p.c];
    if(cell) { cell.appendChild(highlight); highlights.push(highlight); }
  });
}

function onCellClick(r,c){
  if(!playerTurn) return;
  const piece = boardState[r][c];
  if(selectedPiece){
    const {captures,simple}=getMoves(selectedPiece.r, selectedPiece.c);
    const moves=captures.length>0 ? captures : simple;
    const valid=moves.some(m=>m.r===r && m.c===c);
    if(valid){
      movePiece(selectedPiece.r,selectedPiece.c,r,c);
      selectedPiece=null;
      clearHighlights();
      playerTurn=false;
      setTimeout(()=>{ checkGameOver(); botMove(); },500);
    } else { selectedPiece=null; clearHighlights(); }
  } else if(piece && piece.type==="player"){ selectedPiece={r,c}; showHighlights(r,c); }
}

function movePiece(sr,sc,dr,dc){
  const piece = boardState[sr][sc];
  if(!piece) return;

  const deltaR=dr-sr, deltaC=dc-sc;
  const stepR = deltaR===0?0:deltaR/Math.abs(deltaR);
  const stepC = deltaC===0?0:deltaC/Math.abs(deltaC);

  let r=sr+stepR, c=sc+stepC;
  while(r!==dr || c!==dc){
    const target=boardState[r][c];
    if(target && target.type!==piece.type){
      boardState[r][c]=null;
      const cell=board.children[r*8+c];
      if(cell && cell.firstChild) cell.firstChild.remove();
      break;
    }
    r+=stepR; c+=stepC;
  }

  boardState[dr][dc]=piece;
  boardState[sr][sc]=null;
  const movingDiv=board.children[sr*8+sc]?.firstChild;
  if(movingDiv) board.children[dr*8+dc].appendChild(movingDiv);

  if((piece.type==="player" && dr===0) || (piece.type==="bot" && dr===7)){
    piece.king=true;
    if(movingDiv) {
      if(piece.type==="player") movingDiv.style.backgroundColor="gold";
      else movingDiv.style.backgroundColor="silver";
    }
  }
}

function botMove(){
  let moves=[];
  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const piece=boardState[r][c];
      if(piece && piece.type==="bot"){
        const {captures,simple}=getMoves(r,c);
        const paths=captures.length>0 ? captures : simple;
        paths.forEach(p=>moves.push({sr:r,sc:c,dr:p.r,dc:p.c}));
      }
    }
  }
  if(moves.length>0){
    const move=moves[Math.floor(Math.random()*moves.length)];
    movePiece(move.sr,move.sc,move.dr,move.dc);
  }
  playerTurn=true;
}

function checkGameOver(){
  const flat = boardState.flat();
  const playerPieces = flat.filter(p=>p && p.type==="player");
  const botPieces = flat.filter(p=>p && p.type==="bot");
  if(playerPieces.length===0 || botPieces.length===0){
    alert("Jogo acabou! Reiniciando...");
    initBoard();
  }
}